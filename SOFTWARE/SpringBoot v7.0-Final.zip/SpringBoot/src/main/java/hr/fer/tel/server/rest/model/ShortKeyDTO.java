package hr.fer.tel.server.rest.model;

public record ShortKeyDTO(String name, String value) {

}
