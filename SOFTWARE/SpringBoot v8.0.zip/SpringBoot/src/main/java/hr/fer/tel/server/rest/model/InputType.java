package hr.fer.tel.server.rest.model;

public enum InputType {
	
	BOOLEAN, INTEGER, DECIMAL, DATE, TIME, STRING, SUBMIT;
	
}
