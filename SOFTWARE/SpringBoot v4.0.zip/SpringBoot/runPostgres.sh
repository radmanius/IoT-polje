#!/bin/bash

docker-compose -p iot-platform -f docker-compose-postgres.yml up -d
