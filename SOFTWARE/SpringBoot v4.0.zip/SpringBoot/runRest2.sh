#!/bin/bash

docker-compose -p iot-platform -f docker-compose-rest.yml up -d
